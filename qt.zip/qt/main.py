import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget, QPushButton, QStyleFactory
from PyQt6.QtGui import QFont, QAction, QKeySequence
from flag_widget import FlagWidget
import json
import random
from os.path import join
from PyQt6.QtCore import Qt


class CentralWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.reveal_mode = True
        self.flags_folder = join("country-flags-main", "png")
        self.layout = QVBoxLayout()
        self.country_names = self.load_country_names()

        ctry_img, ctry_name = self.get_random_country()
        self.flag_widget = FlagWidget(join(self.flags_folder, ctry_img + ".png"), ctry_name, parent=self)
        self.name_label = QLabel("?", parent=self)
        self.button = QPushButton("Reveal", parent=self)

        self.layout.addWidget(self.flag_widget)
        self.layout.addWidget(self.name_label, alignment=Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.button, alignment=Qt.AlignmentFlag.AlignCenter)
        self.setLayout(self.layout)

        self.set_connections()

    def set_connections(self):
        self.button.clicked.connect(self.reveal_country_name)

        self.shortcut = QAction(self)
        self.shortcut.setShortcut(Qt.Key.Key_Space)
        self.shortcut.triggered.connect(self.button.click)
        self.addAction(self.shortcut)

    def reveal_country_name(self):
        if self.reveal_mode:
            self.reveal_mode = False
            self.name_label.setText(self.flag_widget.ctry_name)
            self.button.setText("Next")
        else:
            self.reveal_mode = True
            self.update_flag_widget()
            self.name_label.setText("?")
            self.button.setText("Reveal")

    def get_random_country(self):
        country_idx = random.randint(0, len(self.country_names) - 1)
        file_name, ctry_name = self.country_names[country_idx]
        return file_name, ctry_name

    def update_flag_widget(self):
        ctry_img, ctry_name = self.get_random_country()
        self.flag_widget.set_flag_path(join(self.flags_folder, ctry_img + ".png"), ctry_name)

    def load_country_names(self):
        with open("country-flags-main/countries.json", "r", encoding="utf-8") as f:
            names_dict = json.load(f)
            return [(key.lower(), value) for key, value in names_dict.items()]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setGeometry(100, 100, 1000, 600)
        self.setMinimumSize(200, 200)
        self.setWindowTitle("Flag Puzzle App")

        close_action = QAction("Close", self)
        close_action.setShortcut(QKeySequence.StandardKey.Close)
        close_action.triggered.connect(self.close)
        self.addAction(close_action)

        self.central_widget = CentralWidget(self)
        self.setCentralWidget(self.central_widget)


def main():
    app = QApplication(sys.argv)
    app.setStyle(QStyleFactory.create("Fusion"))
    app.setFont(QFont("Sans Serif", 50))
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
